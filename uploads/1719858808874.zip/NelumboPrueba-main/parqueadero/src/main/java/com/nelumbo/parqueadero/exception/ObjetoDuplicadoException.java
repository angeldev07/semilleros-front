package com.nelumbo.parqueadero.exception;

public class ObjetoDuplicadoException extends RuntimeException{

    public ObjetoDuplicadoException(String message){
        super(message);
    }
}
