package com.nelumbo.parqueadero.exception;


public class CampoInsuficienteException extends RuntimeException{

    public CampoInsuficienteException(String message){
        super(message);
    }
}