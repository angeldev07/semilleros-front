package com.nelumbo.parqueadero.exception;

public class ObjetoNoExisteException extends RuntimeException{

    public ObjetoNoExisteException(String message){
        super(message);
    }
}
