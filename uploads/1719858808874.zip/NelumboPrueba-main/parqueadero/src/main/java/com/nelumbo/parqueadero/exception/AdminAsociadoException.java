package com.nelumbo.parqueadero.exception;

public class AdminAsociadoException extends RuntimeException{

    public AdminAsociadoException(String message){
        super(message);
    }
}
