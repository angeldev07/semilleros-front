package com.nelumbo.mensaje;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MensajeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MensajeApplication.class, args);
	}

}
