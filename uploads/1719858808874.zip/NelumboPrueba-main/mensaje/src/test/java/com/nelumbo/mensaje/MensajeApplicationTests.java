package com.nelumbo.mensaje;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MensajeApplicationTests {

	@Test
	void contextLoads() {
	}

}
